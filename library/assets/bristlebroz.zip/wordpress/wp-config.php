<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'bristlebros');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '%s><NEBk<|Ep8Tg; UktX.yyyz4Y=.q[ELDFTzG:=yM+:hhuD2`RcOacml}kYO=q');
define('SECURE_AUTH_KEY',  '<?NJ3#fMu=%l_(d,C@Z2)4-$CGT<Y1v<f`8lpxcVd+P}W=m!LLT L37@lm2*}r`4');
define('LOGGED_IN_KEY',    '{/f$7o]5+Z|&l&CSm?/Q2WBHEk43ks<-@r`K/<-|xeDy;TT DXPG@kP>sRa/y]A+');
define('NONCE_KEY',        '4U>}4 ,DP~j;vI!vUYE5,AJePw_w/dbYiu+QX#hnQ#p+G{K]EnM#KpGBlS[<2h0W');
define('AUTH_SALT',        '<RX|)h0b&To6%tp.F[^O0|B<[QukvP:_(FMEu6 P32!JR?gb^pWy<1:UXAB}bTr]');
define('SECURE_AUTH_SALT', 'bT&.],jWPp3DjWw&bMf_!:DHv@SMqiVdk8(k)HYw6?<QShiVDV2R0jLN 8P#X,lE');
define('LOGGED_IN_SALT',   ',5K#Z^X2nMq%<S !u%r[du.{VNsUfx=[U<B#@{YaqA7rST?+[ !Ondf&8ik|wB7M');
define('NONCE_SALT',       ')zC#IDam=HZ-1JxW-Mq_@T5`mpgdKg;`0`%.?? uS?F%Z`=GaTm.#]^NTr#,XT(H');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
